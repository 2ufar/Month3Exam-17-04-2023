package handler

import (
	_ "exam/api/docs"
	"exam/api/models"
	"exam/pkg/check"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

// CustomerLogin godoc
// @Router       /customer/login [POST]
// @Summary      Customer login
// @Description  Authenticate customer access
// @Tags         auth
// @Accept       json
// @Produce      json
// @Param        login body models.CustomerLoginRequest true "login"
// @Success      201  {object}  models.CustomerLoginResponse
// @Failure      400  {object}  models.Response
// @Failure      404  {object}  models.Response
// @Failure      500  {object}  models.Response
func (h *Handler) CustomerLogin(c *gin.Context) {
	loginReq := models.CustomerLoginRequest{}

	if err := c.ShouldBindJSON(&loginReq); err != nil {
		logResponse(c, h.Log, "Failed to process login data", http.StatusBadRequest, err)
		return
	}
	fmt.Println("loginReq:", loginReq)

	if err := check.ValidatePhoneNumberOfCustomer(loginReq.Login); !true {
		logResponse(c, h.Log, "Provided email is invalid: "+loginReq.Login, http.StatusBadRequest, err)
		return
	}

	if err := check.ValidatePassword(loginReq.Password); !true {
		logResponse(c, h.Log, "Password does not meet security requirements: "+loginReq.Password, http.StatusBadRequest, err)
		return
	}

	loginResp, err := h.Services.Auth().CustomerLogin(c.Request.Context(), loginReq)
	if err != nil {
		logResponse(c, h.Log, "Login attempt failed", http.StatusUnauthorized, err)
		return
	}
	logResponse(c, h.Log, "Login successful", http.StatusOK, loginResp)
}

// CustomerRegister godoc
// @Router       /customer/register [POST]
// @Summary      Customer registration
// @Description  Register a new customer
// @Tags         auth
// @Accept       json
// @Produce      json
// @Param        register body models.CustomerRegisterRequest true "register"
// @Success      201  {object}  models.Response
// @Failure      400  {object}  models.Response
// @Failure      404  {object}  models.Response
// @Failure      500  {object}  models.Response
func (h *Handler) CustomerRegister(c *gin.Context) {
	loginReq := models.CustomerRegisterRequest{}

	if err := c.ShouldBindJSON(&loginReq); err != nil {
		logResponse(c, h.Log, "Failed to read registration data", http.StatusBadRequest, err)
		return
	}

	if err := check.EmailCheck(loginReq.Mail); err != nil {
		logResponse(c, h.Log, "Email validation failed for: "+loginReq.Mail, http.StatusBadRequest, err.Error())
		return
	}

	err := h.Services.Auth().CustomerRegister(c.Request.Context(), loginReq)
	if err != nil {
		logResponse(c, h.Log, "Registration failed", http.StatusInternalServerError, err)
		return
	}
	logResponse(c, h.Log, "Verification email sent successfully", http.StatusOK, "Registration initiated")
}

// CustomerRegister godoc
// @Router       /customer/register-confirm [POST]
// @Summary      Confirm customer registration
// @Description  Confirm email verification
// @Tags         auth
// @Accept       json
// @Produce      json
// @Param        register body models.CustomerRegisterConfRequest true "register"
// @Success      201  {object}  models.CustomerLoginResponse
// @Failure      400  {object}  models.Response
// @Failure      404  {object}  models.Response
// @Failure      500  {object}  models.Response
func (h *Handler) CustomerRegisterConfirm(c *gin.Context) {
	req := models.CustomerRegisterConfRequest{}

	if err := c.ShouldBindJSON(&req); err != nil {
		logResponse(c, h.Log, "Failed to process confirmation data", http.StatusBadRequest, err)
		return
	}
	fmt.Println("req: ", req)

	if err := check.EmailCheck(req.Mail); err != nil {
		logResponse(c, h.Log, "Email validation failed during confirmation for: ", http.StatusBadRequest, err.Error())
	}

	confResp, err := h.Services.Auth().CustomerRegisterConfirm(c.Request.Context(), req)
	if err != nil {
		logResponse(c, h.Log, "Registration confirmation failed", http.StatusUnauthorized, err.Error())
		return
	}

	logResponse(c, h.Log, "Registration confirmed successfully", http.StatusOK, confResp)

}
